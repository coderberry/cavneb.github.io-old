var App = Ember.Application.create();

App.ApplicationController = Ember.ObjectController.extend({
  message: 'This is the text that should be copied'
});

Ember.Handlebars.helper('zeroClipboard', Ember.View.extend({
  tagName: 'button',
  classNames: ['btn'],
  attributeBindings: ['title', 'data-clipboard-text'],
  title: 'Copy to clipboard',

  didInsertElement: function() {
    var clip = new ZeroClipboard(this.$(), {
      moviePath: "/ZeroClipboard.swf"
    });

    clip.on( 'complete', function(client, args) {
      alert('Copied "' + args.text + '" to clipboard');
    });
  }
}));